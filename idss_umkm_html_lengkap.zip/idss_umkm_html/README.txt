IDSS UMKM | KONVERSI HTML DIPERLUAS

Sumber: idss_umkm_fuzzy.zip asli dari pengguna.

TERJAGA:
- Aset CSS dan gambar asli.
- Konfigurasi fuzzy Mamdani v1.0, seluruh 27 aturan asli, dan batas kategori asli, diekstraksi dari database/idss_umkm.sql.
- Dataset UMKM dan evaluasi asli TIDAK ada di SQL yang diunggah (tabel tersedia tanpa baris INSERT). Tidak ada data fiktif ditambahkan.
- Akun awal dalam SQL adalah metadata autentikasi server, tidak diterapkan sebagai login statis untuk keamanan.

FITUR HTML:
- Kelola dan impor/ekspor UMKM CSV, field tambahan mengikuti skema SQL asli.
- Evaluasi satu dan massal; algoritma JavaScript mengikuti fungsi keanggotaan, MIN-MAX dan centroid langkah 0.1 pada Fuzzy_mamdani.php.
- Riwayat, detail aturan aktif, laporan, backup/restore JSON.
- Semua hasil tersimpan hanya di localStorage perangkat/browser (tidak ada database terhubung).

JALANKAN: ekstrak ZIP, buka terminal di folder situs, jalankan 'python -m http.server 8000', lalu http://localhost:8000. Live Server di VS Code juga bisa. Server lokal diperlukan untuk pemuatan file model JSON.

CATATAN: kecocokan numerik mesin JavaScript dengan implementasi PHP belum diuji komparatif menggunakan dataset historis yang tidak tersedia. Ini bukan pengganti autentikasi dan backend PHP untuk produksi.
